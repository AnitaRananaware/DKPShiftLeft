﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    partial class Calculator
    {
        public void Add()
        {
            Console.WriteLine("\n\t Add Method");
        }
    }
}
