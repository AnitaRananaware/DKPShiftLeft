﻿namespace ConsoleApp1
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            //Calculator calculator = new Calculator();
            //calculator.Add();
            //calculator.Mul();
            //calculator.Sub();

            dynamic i;

            i = 90;
            Console.WriteLine(i.GetType());

            i = "SSS";
            Console.WriteLine(i.GetType());

           
          

        




        }
    }
}