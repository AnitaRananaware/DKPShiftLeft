﻿using System.ComponentModel;

namespace PolymorphismDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Emp eobj = new Emp();
            //eobj.CalculateSalary();

            //Sales sobj = new Sales();
            //sobj.CalculateSalary();

            //Emp obj = new Sales();
            //Console.WriteLine(obj.GetType());
            //obj.CalculateSalary();

            Emp obj; int ch;
            do
            {
                Console.WriteLine("\n\t 1. Sales \n\t 2.Manager \n\t 3. Exit ");
                Console.Write("\t Enter Choice :- ");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        obj = new Sales(101,"AAAA",2000,345);
                        obj.CalculateSalary();
                        break;
                    case 2:
                        obj = new Manager(102,"NNNN",6000,200,300);
                        obj.CalculateSalary();
                        break;
                    case 3:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\n\t Enetr valid choice");
                        break;
                }
            } while (ch!=3);
        }
    }
}