﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    internal class Emp
    {
        int empId;
        string empName;
        protected double empSalary;   // accessible in derived class

        public Emp()
        {
           // Console.WriteLine("\n\t Emp Default Constructor");
        }

        public Emp(int empId, string empName, double empSalary)
        {
            this.empId = empId;
            this.empName = empName;
            this.empSalary = empSalary;
            //Console.WriteLine("\n\t Emp Parameterized Constructor");
        }

        public void Accept()
        {
            Console.Write("\n\t Enter Id :- ");
            empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("\tEnter Name:- ");
            empName = Console.ReadLine();
            Console.Write("\t Enter Salary : ");
            empSalary = Convert.ToDouble(Console.ReadLine());
        }
        public void Display()
        {
            Console.WriteLine("\t{0} \t {1} \t {2}",empId,empName, empSalary);
        }

        public virtual void CalculateSalary()
        {
            Console.WriteLine("\n\t Emp Class Basic Salary :- " + empSalary);
        }
    }
}
