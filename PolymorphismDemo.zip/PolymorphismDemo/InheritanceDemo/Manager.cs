﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    internal class Manager : Emp
    {
        double foodAll;
        double travelAll;

        public Manager()
        {
            
        }

        public Manager(int empId, string name, double sal, double foodAll, double travelAll):base(empId,name,sal)
        {
            this.foodAll = foodAll;
            this.travelAll = travelAll;
        }

        public new void Display()
        {
            base.Display();
            Console.WriteLine("\t Food Allowances : " + foodAll);
            Console.WriteLine("\t Travel Allowances:- " + travelAll);
        }

        public override void CalculateSalary()
        {
            Console.WriteLine("\n\t Manager Total Salary : " + (empSalary+foodAll+travelAll));
        }
    }
}
