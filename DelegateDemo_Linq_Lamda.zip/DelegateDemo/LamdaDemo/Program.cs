﻿namespace LamdaDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  left  =>  right
            //  (parameters)   =>   statements

            List<int> list = new List<int>() { 34, 12, 56, 97, 53, 67, 90, 65 };

            //var data = from i in list
            //           where i%2==0
            //           select i;

            var data = list.FindAll(n => n%2==0).ToList();
            Console.WriteLine("\t Even :- " + string.Join(", ", data));

            var squere = list.Select(x => x*x).ToList();
            Console.WriteLine("\t Square :- " + string.Join(", ", squere));

            var num = list.Where(x => x==53).FirstOrDefault();
            Console.WriteLine("\t Find 53 :- " + num);

        }
    }
}