﻿using System.Diagnostics.CodeAnalysis;

namespace LinqDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //List<int> list = new List<int>() { 34, 12, 56, 97, 53, 67, 90, 65 };

            //var data = from n in list
            //           //where n > 60
            //           where n%2==0
            //           orderby n descending
            //           select n;

            //foreach (int i in data)
            //{
            //    Console.WriteLine("\t" + i);
            //}
            List<Emp> employees = new List<Emp>()
            {
                new Emp(){EmpId = 101,Name="Rajat", Salary=3000,Designation="Manager",DeptNo=10},
                new Emp(){EmpId = 102,Name="Amith", Salary=7000,Designation="Manager",DeptNo=20},
                new Emp(){EmpId = 103,Name="Smith", Salary=8000,Designation="SalesM",DeptNo=30},
                new Emp(){EmpId = 104,Name="Peter", Salary=2000,Designation="SalesM",DeptNo=10},
                new Emp(){EmpId = 105,Name="Prachi", Salary=9000,Designation="TeamLead",DeptNo=20},
                new Emp(){EmpId = 106,Name="King", Salary=7000,Designation="TeamLead",DeptNo=30},
                new Emp(){EmpId = 107,Name="Amar", Salary=3000,Designation="Analyst",DeptNo=10},
                new Emp(){EmpId = 108,Name="Raj", Salary=6000,Designation="Analyst",DeptNo=20},
                new Emp(){EmpId = 109,Name="Sam", Salary=4000,Designation="Analyst",DeptNo=30},
                new Emp(){EmpId = 110,Name="Harry", Salary=5000,Designation="Manager",DeptNo=20},
            };

            List<Dept> depts = new List<Dept>()
            {
                new Dept(){DeptNo=10,DeptName="Sales"},
                new Dept(){DeptNo=20,DeptName="Purchase"},
                new Dept(){DeptNo=30,DeptName="Training"}
            };

            //var data = from e in employees
            //               //where e.Designation=="Manager"
            //               //where e.Name.StartsWith("P")
            //           orderby e.Salary
            //           select new { e.Name, e.Salary } ;

            /*var data = employees.Where(e => e.Designation == "Manager")
                                .OrderByDescending(e => e.Salary)             //.ToList();
                                .Select(e => new { e.Name, e.Salary });

            foreach(var emp in data)
            {
               // Console.WriteLine("{0,-12}{1,-12}{2,-12}{3,-12}{4,-12}",emp.EmpId,emp.Name,emp.Salary,emp.Designation,emp.DeptNo);
                Console.WriteLine("\t" + emp.Name + "\t" + emp.Salary);
            }*/

            //var data = from e in employees
            //           group e
            //           by e.Designation
            //           into empdesg
            //           select empdesg;

            /* var data = employees.GroupBy(e => e.Designation);

             foreach (var empd in data)
             {
                 Console.WriteLine(empd.Key + ".....");
                 foreach(var e in empd)
                 {
                     Console.WriteLine(e.Name);
                 }
                 Console.WriteLine();
             }*/

            //var empdept = from e in employees
            //              join d in depts
            //              on e.DeptNo equals d.DeptNo
            //              select new { e.Name, e.DeptNo, d.DeptName };

            var empdept = employees.Join(depts, e => e.DeptNo, d => d.DeptNo, (e, d) => new { e.Name, e.DeptNo, d.DeptName });
            
            foreach(var ed in empdept)
            {
                Console.WriteLine("\n\t {0}   {1}   {2}",ed.Name,ed.DeptNo,ed.DeptName);
            }





        }
    }
}