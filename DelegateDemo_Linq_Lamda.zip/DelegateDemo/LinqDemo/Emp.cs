﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo
{
    internal class Emp
    {
        public int EmpId { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
        public string Designation { get; set; }
        public int DeptNo { get; set; }
    }

    class Dept
    {
        public int DeptNo { get; set; }
        public string DeptName { get; set; }
    }
}
