﻿namespace DelegateDemo
{
    delegate void strDelegate(string str);    //1. Declaration

    delegate void SampleDelegete();

    delegate int MathDelegate(int num1, int num2);

    internal class Program
    {
        static void Main(string[] args)
        {
            //2. Instantiate
            //strDelegate del1 = new strDelegate(Demo.UpperCase);
            //strDelegate del2 = Demo.LowerCase;
            //strDelegate del3 = new strDelegate(Demo.Reverse);

            //strDelegate del;
            //del= del1;
            //del += del2;
            //del += del3;

            ////3. Invoke
            ////string str=
            //del("ShiftLeft");
            ////Console.WriteLine("\n\t " + str);
            ///

            SampleDelegete del = delegate () { Console.WriteLine("Hello"); };
            del();

            MathDelegate Mdel = delegate(int n1, int n2) { return(n1+n2);};
            int add =  Mdel(34, 90);
            Console.WriteLine("\n\t Add: " + add);
        }
    }
}