﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    internal class Demo
    {
        public static void UpperCase(string str)
        {
            Console.WriteLine("\n\t " + str.ToUpper());
            //return str.ToUpper();
        }

        public static void LowerCase(string str)
        {
            Console.WriteLine("\n\t " + str.ToLower());
            //return str.ToLower();
        }

        public static void Reverse(string str)
        {
            char[] chars = str.ToCharArray();
            Array.Reverse(chars);
            str = new string(chars);
            Console.WriteLine("\n\t " + str);
            //return str;
        }
    }
}
