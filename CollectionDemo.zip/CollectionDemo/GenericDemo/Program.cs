﻿using System.Collections;
using System.Collections.Generic;

namespace GenericDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int,string> dic = new Dictionary<int,string>();
            dic.Add(12, "SSS");
            dic.Add(23, "FFFF");
            dic.Add(10, "GGG");

            foreach(KeyValuePair<int,string> entry in dic)
            {
                Console.WriteLine(entry.Key  +" " + entry.Value);
            }
                                  
        }
    }
}