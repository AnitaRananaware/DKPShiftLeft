﻿namespace Demo2_Generic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Emp> emplist = new List<Emp>() 
            {
                new Emp() {EmpId=1,Name="Peter",Salary=8000},
                new Emp() {EmpId=2,Name="Smith",Salary=5000},
                new Emp() {EmpId=3, Name ="Raj", Salary=10000}
            };
            
           emplist.Add(new Emp() { EmpId = 344, Name = "Ram",Salary= 6000 });

            emplist.Sort();

            foreach (Emp emp in emplist)
            {
                Console.WriteLine("{0,-10}{1,-15}{2,-10}",emp.EmpId,emp.Name,emp.Salary);
            }

          
        }
    }
}