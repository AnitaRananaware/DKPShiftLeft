﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Demo2_Generic
{
    internal class Emp : IComparable
    {
        public int EmpId { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }

        public int CompareTo(object? obj)
        {
            Emp temp = (Emp) obj;
            if(temp.Salary > this.Salary)
                return 1;
            else 
                if(temp.Salary < this.Salary)
                    return -1;
                else
                    return 0;
        }

       
    }
}
