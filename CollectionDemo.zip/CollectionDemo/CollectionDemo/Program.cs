﻿using System.Globalization;
using System.Collections;
using System.Collections.Generic;

namespace CollectionDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int[] numbers = { 23, 66, 22, 90, 85, 72, 62, 48, 19 };

            //IEnumerator e = numbers.GetEnumerator();
            //while (e.MoveNext())
            //{
            //    Console.WriteLine(e.Current);
            //}

            ArrayList list = new ArrayList();

            list.Add(900);
            list.Add(23);
            list.Add(34);
            list.Add(67); ;
            list.Add(90);

            //Console.WriteLine(list.Capacity);
            //Console.WriteLine(list.Count);
            //list.Insert(3, "NewElement");

            //list.Remove(23);
            //list.RemoveAt(3);

            list.Sort();
            IEnumerator e = list.GetEnumerator();
            while (e.MoveNext())
            {
                Console.WriteLine("\n\t " + e.Current);
            }

            // foreach(object o in list)
            // {
            //     Console.WriteLine(o.ToString());
            // }

            //Stack stk = new Stack();
            //Stack<int> stack = new Stack<int>();
            //stack.Push(55);
            //stk.Push(10);
            //stk.Push(30);
            //stk.Push(20);
            //stk.Push(40);

            //Console.WriteLine(stk.Pop());
            //Console.WriteLine(stk.Peek());

            //Queue queue = new Queue();  // FIFO
            //Queue<double> queue = new Queue<double>();
           // queue.Enqueue(23.45);
            //queue.Enqueue(11);
            //queue.Enqueue(12);
            //queue.Enqueue(13);
            //queue.Enqueue(14);
            //queue.Enqueue(15);

            //Console.WriteLine(queue.Dequeue());
            //Console.WriteLine(queue.Peek());
            
            //Hashtable ht = new Hashtable();
           // SortedList ht = new SortedList();
           // ht.Add(11, "Aarati");
           //// ht.Add("Aarati", 11);
           // ht.Add(14, "Ram");
           // ht.Add(16, "Seeta");
           // ht.Add(12, "Raj");

           // foreach(DictionaryEntry entry in ht)
           // {
           //     Console.WriteLine("\n\t" + entry.Key + "  " + entry.Value);
           // }

            //IDictionaryEnumerator e =  ht.GetEnumerator();
            //while (e.MoveNext())
            //{
            //    Console.WriteLine("\n\t " + e.Key  + "\t" + e.Value);
            //}


        }
    }
}