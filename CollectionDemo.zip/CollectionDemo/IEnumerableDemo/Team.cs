﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerableDemo
{
    internal class Team : IEnumerable
    {
        List<Player> players;

        public Team()
        {
            players = new List<Player>()
            {
                new Player(){ Name="Sachin", Runs=90},
                new Player(){ Name="Raj", Runs=78},
                new Player(){ Name="Virat", Runs=23},
                new Player(){ Name="Sam", Runs=98},
                new Player(){ Name="Yuvi", Runs=65},
                new Player(){ Name="Saurbh", Runs=38}
            };
        }

        public IEnumerator GetEnumerator()
        {
            return players.GetEnumerator();
        }
    }
}
