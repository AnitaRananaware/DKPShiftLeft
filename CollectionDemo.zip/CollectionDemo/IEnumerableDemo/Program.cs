﻿namespace IEnumerableDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Team team = new Team();  //.. team contains the  colln of players

            foreach(Player p in team)  // support foreach .. IEnumerable
            {
                Console.WriteLine("\n\t" + p.Name + "\t" + p.Runs);
            }
        }
    }
}