﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerableDemo
{
    internal class Player
    {
        public int Runs { get; set; }
        public string Name { get; set; }
    }
}
