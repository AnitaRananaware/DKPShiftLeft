﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3_Interface
{
    class PlayerCompare : IComparer<Player>
    {
        public int Compare(Player? x, Player? y)
        {
            return y.Runs.CompareTo(x.Runs);
        }
    }

    internal class Player
    {
        public int Runs { get; set; }
        public string Name { get; set; }
    }
}
