﻿using System.Security.Cryptography.X509Certificates;

namespace Demo3_Interface
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Player> players = new List<Player>()
            {
                new Player(){ Name="Sachin", Runs=90},
                new Player(){ Name="Raj", Runs=78},
                new Player(){ Name="Virat", Runs=23},
                new Player(){ Name="Sam", Runs=98},
                new Player(){ Name="Yuvi", Runs=65},
                new Player(){ Name="Saurbh", Runs=38},
            };

            PlayerCompare pc = new PlayerCompare();
            players.Sort(pc);

            foreach (Player p in players)
            {
                Console.WriteLine("\n\t" + p.Name + "\t" + p.Runs);
            }
        }
    }
}