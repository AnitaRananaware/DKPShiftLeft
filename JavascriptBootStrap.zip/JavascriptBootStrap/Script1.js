// JavaScript source code

function Greet() {
    alert("WelCome!!!");
    document.body.style.backgroundColor = "cyan";
}