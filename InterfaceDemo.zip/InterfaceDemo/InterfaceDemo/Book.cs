﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    internal class Book : Idisplay
    {
        public void Display()
        {
            Console.WriteLine("\n\t Book Class .. Idisplay interface");
        }
    }
}
