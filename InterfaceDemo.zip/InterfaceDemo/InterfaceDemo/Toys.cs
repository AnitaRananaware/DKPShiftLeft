﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    internal class Toys : Idisplay, IPrint
    {
        public void Display()
        {
            Console.WriteLine("\n\t Toys Class .. IPrint interface");
        }

        public void Hi()
        {

        }

        void Idisplay.Display()
        {
            Console.WriteLine("\n\t Toys Class .. Idisplay interface");
        }
    }
}
