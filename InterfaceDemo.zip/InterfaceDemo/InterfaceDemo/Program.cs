﻿namespace InterfaceDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Emp e = new Emp();
            e.Display();

            Idisplay d = new Toys();
            d.Display();

            IPrint p = new Toys();
            p.Display();
            
        }
    }
}