﻿using ProductLib.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLib.Repository
{
    public interface IProductService
    {
        List<Product> GetProducts();
        Product GetProductById(int id);
        List<Product> GetProductByName(string name);
        Product EditProduct(Product product);
    }
}
