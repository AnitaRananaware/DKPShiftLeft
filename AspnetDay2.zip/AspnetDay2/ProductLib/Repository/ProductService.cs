﻿using ProductLib.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLib.Repository
{
    public class ProductService : IProductService
    {
        static List<Product> products = new List<Product>();

        static ProductService()
        {
            products.Add(new Product() { ProductId=101, ProductName="Table",Price=900});
            products.Add(new Product() { ProductId = 102, ProductName = "Chair", Price = 400 });
            products.Add(new Product() { ProductId = 103, ProductName = "T.V unit", Price = 600 });
            products.Add(new Product() { ProductId = 104, ProductName = "Food Processor", Price = 400 });
            products.Add(new Product() { ProductId = 105, ProductName = "Mixer Grinder", Price = 700 });
            products.Add(new Product() { ProductId = 106, ProductName = "Laptop", Price = 400 });
        }

        public Product EditProduct(Product product)
        {
            foreach (var item in products)
            {
                if(item.ProductId == product.ProductId)
                {
                    item.ProductName = product.ProductName;
                    item.Price = product.Price;

                    return item;
                }
            }
            return null;
        }

        public Product GetProductById(int id)
        {
            return products.Where(p => p.ProductId == id).FirstOrDefault();
        }

        public List<Product> GetProductByName(string name)
        {
            return products.Where(p => p.ProductName == name).ToList();
        }

        public List<Product> GetProducts()
        {
            return products;
        }

    }
}
