using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductLib.Model;
using ProductLib.Repository;

namespace AspnetDay2.Pages
{
    public class ProductListModel : PageModel
    {
        IProductService productService;

        public List<Product> Products { get; set; }

        public ProductListModel(IProductService service)
        {
            productService = service;
        }

        public void OnGet()
        {
           Products =  productService.GetProducts();
        }

        public void OnPost(string productName)
        {
            Products = productService.GetProductByName(productName);
        }
    }
}
