using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductLib.Model;
using ProductLib.Repository;

namespace AspnetDay2.Pages
{
    public class EditModel : PageModel
    {
        IProductService productService;
        public Product Product { get; set; }

        public EditModel(IProductService service)
        {
            productService = service;
        }
        public void OnGet(int productId)
        {
            Product = productService.GetProductById(productId);
        }

        public ActionResult OnPost(Product product)
        {
            Product = productService.EditProduct(product);
            return Redirect("./ProductList");
        }
    }
}
