using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductLib.Model;
using ProductLib.Repository;

namespace AspnetDay2.Pages
{
    public class DetailsModel : PageModel
    {
        IProductService productService;

        public Product  Product { get; set; }

        public DetailsModel(IProductService service)
        {
            productService = service;   
        }
        public void OnGet(int productId)
        {
            Product =  productService.GetProductById(productId);
        }
    }
}
