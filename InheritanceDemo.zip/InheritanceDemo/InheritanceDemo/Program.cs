﻿namespace InheritanceDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Sales sales = new Sales(12,"DDDD",343434,456);

           
            //sales.Accept();
            sales.Display();
                     
        }
    }
}