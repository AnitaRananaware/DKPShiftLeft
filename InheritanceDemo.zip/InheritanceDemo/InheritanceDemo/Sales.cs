﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    internal class Sales : Emp
    {
        double incentives;

        public Sales()
        {
            Console.WriteLine("\n\t Sales Default Constructor");
        }

        public Sales(double incentives)
        {
            Console.WriteLine("\n\t Sales Parameterized Constructor");
            this.incentives = incentives;
        }

        public Sales(int id, string nm, double sal, double incen):base(id,nm,sal)
        {
            incentives = incen;
            Console.WriteLine("\n\t Sales parameterized Constructor");
        }

        public new void Accept()
        {
            base.Accept();
            Console.Write("\t Enter Incentives :- ");
            incentives = Convert.ToDouble(Console.ReadLine());
        }

        public new void Display()
        {
            base.Display();
            Console.WriteLine("\t Incentives : " + incentives);
        }

        public new void CalculateSalary()
        {
            Console.WriteLine("\n\t Sales Total Salary :- " + (empSalary + incentives));
        }
    }
}
