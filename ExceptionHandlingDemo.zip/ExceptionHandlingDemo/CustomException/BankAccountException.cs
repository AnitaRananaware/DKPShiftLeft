﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomException
{
    public class BankAccountException : Exception  //1.
    {
        public string Message; //2

        public BankAccountException(string message) : base(message)  //3
        {
            this.Message = message;
        }
    }
}
