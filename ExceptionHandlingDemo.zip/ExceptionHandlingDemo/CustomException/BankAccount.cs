﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomException
{
    public class BankAccount
    {
        public int Acctno { get; set; }
        public string Name { get; set; }
        public double Balance { get; set; }

        public void Deposite(double amount)
        {
            if(Balance+amount >=10000)
            {
                throw new BankAccountException("Balance Overflow... limit 10000.. applicatble To Tax");
            }
            Balance = Balance + amount;
        }

        public void Withdraw(double amount)
        {
            if(Balance-amount <= 5000)
            {
                throw new BankAccountException("Minimum balance required 5000...Operation Cancelled");
            }
            Balance = Balance - amount;
        }
    }
}
