﻿namespace CustomException
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount()
            {
               Acctno = 123,
               Name="Test",
               Balance=8000
            };

            Console.WriteLine("\n\t Current balance :- " + account.Balance);
            try
            {
                //account.Withdraw(6000);
                account.Deposite(6000);
            }
            catch (BankAccountException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("\n\t Current balance :- " + account.Balance);

        }
    }
}