﻿namespace ExceptionHandlingDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, div, res;
            try
            {
                Console.Write("\n\t Enter Number :- ");
                num = Convert.ToInt32(Console.ReadLine());
                Console.Write("\n\t Enter Divisor :- ");
                div = Convert.ToInt32(Console.ReadLine());
                res = num / div;

                Console.WriteLine("\n\t Result :- " + res);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("\n\t Enetr numbers only");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("\n\t Number not divisible by zero");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("\n\t This is Finally (Cleanup statements");
            }
            Console.WriteLine("\n\t Continue program....");
        }
    }
}