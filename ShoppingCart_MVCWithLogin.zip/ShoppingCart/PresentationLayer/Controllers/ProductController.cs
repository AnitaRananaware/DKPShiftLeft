﻿using DataAccessLayer;
using DataAccessLayer.Repo;
using Microsoft.AspNetCore.Mvc;
using PresentationLayer.Models;

namespace PresentationLayer.Controllers
{
    public class ProductController : Controller
    {
        IProductService service;

        public ProductController(IProductService service)
        {
            this.service = service;
        }

        //[ActionName("GetProducts")]
        public IActionResult Index()
        {
            if(HttpContext.Session.GetString("EmailId")==null)
            {
                return RedirectToAction("Login", "Login");
            }

            List<Product> Products =  service.GetProducts();

            List<ProductViewModel> ProductsViewModel = new List<ProductViewModel>();
            foreach (Product product in Products)
            {
                ProductViewModel p = new ProductViewModel();
                p.ProductId = product.ProductId;
                p.ProductName = product.ProductName;
                p.Price = product.Price;
                p.Quantity = product.Quantity;

                ProductsViewModel.Add(p);
            }
            return View(ProductsViewModel);
        }

        [HttpGet]
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("EmailId") == null)
            {
                return RedirectToAction("Login", "Login");
            }
            return View();
        }

        [HttpPost]
        public IActionResult Create(ProductViewModel productViewModel)
        {
            Product product = new Product();
            product.ProductId = productViewModel.ProductId;
            product.ProductName = productViewModel.ProductName;
            product.Price = productViewModel.Price;
            product.Quantity = productViewModel.Quantity;

            int i=  service.InsertProduct(product);

            if (i > 0)
            {
                return RedirectToAction("Index");
            }
            return View("Error");
        }

        public ActionResult Details(int id)
        {
            Product p =  service.GetProductById(id);

            ProductViewModel pv = new ProductViewModel();

            pv.ProductId = p.ProductId;
            pv.ProductName = p.ProductName;
            pv.Price = p.Price;
            pv.Quantity = p.Quantity;

            return View(pv);
        }

        public ActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("EmailId") == null)
            {
                return RedirectToAction("Login", "Login");
            }
            Product p = service.GetProductById(id);

            ProductViewModel pv = new ProductViewModel();

            pv.ProductId = p.ProductId;
            pv.ProductName = p.ProductName;
            pv.Price = p.Price;
            pv.Quantity = p.Quantity;

            return View(pv);
        }

        [HttpPost]
        public ActionResult Edit(int id, ProductViewModel pv)
        {
            Product p = new Product();
            p.ProductId = pv.ProductId;
            p.ProductName = pv.ProductName;
            p.Price = pv.Price;
            p.Quantity = pv.Quantity;

           int i=  service.UpdateProduct(id, p);
            if(i>=0)
            {
                return RedirectToAction("Index");
            }
            else
            { return View("Error");
            }
        }

        public ActionResult Delete(int id)
        {
            if (HttpContext.Session.GetString("EmailId") == null)
            {
                return RedirectToAction("Login", "Login");
            }
            Product p = service.GetProductById(id);

            ProductViewModel pv = new ProductViewModel();

            pv.ProductId = p.ProductId;
            pv.ProductName = p.ProductName;
            pv.Price = p.Price;
            pv.Quantity = p.Quantity;

            return View(pv);
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteProduct(int id)
        {
           int i=  service.DeleteProduct(id);
            if (i >= 0)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return View("Error");
            }
        }
    }
}
