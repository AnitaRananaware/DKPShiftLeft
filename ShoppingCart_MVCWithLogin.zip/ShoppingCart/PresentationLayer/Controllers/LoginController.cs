﻿using DataAccessLayer.Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using PresentationLayer.Models;

namespace PresentationLayer.Controllers
{
    public class LoginController : Controller
    {
        IProductService service;

        public LoginController(IProductService service)
        {
            this.service = service;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(UserViewModel user)
        {
           bool flag =  service.ValidateUser(user.EmailId, user.Password);
            if (flag)
            {
                HttpContext.Session.SetString("EmailId", user.EmailId);
                return RedirectToAction("Index", "Product");
            }
            else
            {
                ViewData["msg"] = "Invalid Username and Password";
                return View();
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
