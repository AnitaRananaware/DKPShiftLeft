﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace PresentationLayer.Models
{
    public class UserViewModel
    {
        [Key]
        [EmailAddress]
        public string EmailId { get; set; }
        [PasswordPropertyText]
        public string Password { get; set; }
    }
}
