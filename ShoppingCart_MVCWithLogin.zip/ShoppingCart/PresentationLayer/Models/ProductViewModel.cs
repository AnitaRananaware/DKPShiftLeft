﻿using System.ComponentModel.DataAnnotations;

namespace PresentationLayer.Models
{
    public class ProductViewModel
    {
        [Key]
        [Display(Name ="Product Id")]
        public int ProductId { get; set; }
        [Required]
        [StringLength(20)]
        [RegularExpression("^[A-z]{2,20}$",ErrorMessage ="Enetr Valid Name")]
        public string ProductName { get; set; }
        [Required]
        [Range(100,90000)]
        public double Price { get; set; }
        [Display(Name = "Product Quantity")]
        public int? Quantity { get; set; }
    }
}
