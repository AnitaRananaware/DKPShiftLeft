﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repo
{
    public interface IProductService
    {
        List<Product> GetProducts();
        int InsertProduct(Product product);
        int UpdateProduct(int id, Product newproduct);
        int DeleteProduct(int id);
        Product GetProductById(int id);

        bool ValidateUser(string EmailId, string Password);
    }
}
