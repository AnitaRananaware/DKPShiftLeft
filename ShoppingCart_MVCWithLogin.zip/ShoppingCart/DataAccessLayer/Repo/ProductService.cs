﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repo
{
    public class ProductService : IProductService
    {
        ProductContext context = new ProductContext();

        public int DeleteProduct(int id)
        {
            Product product = context.Products.Find(id);
            if (product != null)
            {
                context.Products.Remove(product);
                return context.SaveChanges();
            }
            return 0;
        }

        public Product GetProductById(int id)
        {
            return context.Products.Find(id);
        }

        public List<Product> GetProducts()
        {
           return context.Products.ToList();
        }

        public int InsertProduct(Product product)
        {
            context.Products.Add(product);
            return context.SaveChanges();
        }

        public int UpdateProduct(int id, Product newproduct)
        {
            Product old = context.Products.Find(id);
            if (old != null)
            {
                old.ProductName = newproduct.ProductName;
                old.Price = newproduct.Price;
                old.Quantity = newproduct.Quantity;

                return context.SaveChanges();
            }
            return 0;
        }

        public bool ValidateUser(string EmailId, string Password)
        {
           var user =  context.Users.Where(u => u.EmailId==EmailId && u.Password==Password).SingleOrDefault();
            if (user != null)
            {
                return true;
            }
            else
            { return false; }
        }
    }
}
